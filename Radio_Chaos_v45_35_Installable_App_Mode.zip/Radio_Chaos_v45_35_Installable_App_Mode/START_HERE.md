# Radio Chaos v45.35: Installable App Mode

This is an **installable web app (PWA)**, not an App Store/native iOS binary. The working HTML audio code is preserved.

## Installation on iPhone 14 Plus
1. Host this folder on a private **HTTPS** website (or run the Python server locally for desktop testing). Opening the HTML directly in Files does not enable PWA installation or the service worker.
2. Open the HTTPS address in **Safari** on the iPhone.
3. Tap **Share → Add to Home Screen → Add**.
4. Launch Radio Chaos using the new Home Screen icon. It opens in standalone full-screen app mode.

## Local desktop test
`python stem_server.py --host 127.0.0.1 --port 8765` then open `http://127.0.0.1:8765/`.
Stem separation requires the optional AI dependencies and server token. The service worker caches only the application shell and icons, **not** audio files or stem API responses. Offline app shell does not mean offline AI stem separation.

**Not verified:** installation on physical iOS 27, audio playback from installed mode, background audio, model inference, remote HTTPS deployment.
