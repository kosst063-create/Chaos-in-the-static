import unittest,tempfile,wave,struct,math,sys,subprocess,os,json,urllib.request,urllib.error,time
from pathlib import Path
import stem_server as srv
class AudioPreflight(unittest.TestCase):
 def test_invalid_bytes(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'bad.wav';p.write_bytes(b'not real audio'*30)
   with self.assertRaises(RuntimeError):srv.probe_audio(p)
 def test_valid_diagnostic_wav(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'diagnostic.wav'
   with wave.open(str(p),'wb') as w:
    w.setnchannels(1);w.setsampwidth(2);w.setframerate(8000)
    w.writeframes(b''.join(struct.pack('<h',int(3000*math.sin(2*math.pi*440*i/8000))) for i in range(8000)))
   info=srv.probe_audio(p)
   self.assertEqual(info['channels'],1)
   self.assertAlmostEqual(info['duration_seconds'],1.0,places=2)
   self.assertEqual(info['sample_rate'],8000)
 def test_app_path(self):self.assertTrue(srv.APP.is_file())
 def test_models(self):self.assertIn('htdemucs_6s',srv.MODELS);self.assertIn('uvr-mdx-inst-hq3',srv.MODELS)
if __name__=='__main__':unittest.main()
