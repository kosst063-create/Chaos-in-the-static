from pathlib import Path
import ast, unittest
ROOT=Path(__file__).resolve().parent
class ServerConsistency(unittest.TestCase):
 def test_server_syntax(self): ast.parse((ROOT/'stem_server.py').read_text())
 def test_app_exists(self):
  source=(ROOT/'stem_server.py').read_text()
  self.assertIn("APP=HERE/'Radio_Chaos_v45_31_Server_UI_Consistency.html'",source)
  self.assertTrue((ROOT/'Radio_Chaos_v45_31_Server_UI_Consistency.html').exists())
 def test_routes(self):
  s=(ROOT/'stem_server.py').read_text()
  self.assertIn("'/Radio_Chaos_v45_31_Server_UI_Consistency.html'",s)
  self.assertIn("'/rc-stems/health'",s)
 def test_dual_engine_preserved(self):
  s=(ROOT/'stem_server.py').read_text()
  self.assertIn("uvr-mdx-inst-hq3",s)
  self.assertIn("htdemucs",s)
 def test_ui_controls_preserved(self):
  s=(ROOT/'Radio_Chaos_v45_31_Server_UI_Consistency.html').read_text()
  for token in ('rc4529TouchDock','rc4530UnifiedNav','rcVoiceCommands4523','rcCarAudio','rcQuickStemImportPanel'):
   self.assertIn(token,s)
if __name__=='__main__':unittest.main()
