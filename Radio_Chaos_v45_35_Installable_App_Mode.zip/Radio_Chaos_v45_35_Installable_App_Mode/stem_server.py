#!/usr/bin/env python3
"""Radio Chaos 45.9: a genuine Demucs CPU/GPU stem service and same-origin web host.

Run: python rc459_stem_server.py --host 127.0.0.1 --port 8765
For iPhone on a trusted private LAN: --host 0.0.0.0; use http://YOUR_COMPUTER_IP:8765
The service runs real `python -m demucs`. It does NOT synthesize substitutes.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,unquote
import importlib.util
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import uuid
import zipfile

HERE=Path(__file__).resolve().parent
APP=HERE/'Radio_Chaos_v45_35_Installable_App_Mode.html'
ROOT=Path(os.getenv('RADIO_CHAOS_STEMS_DIR',str(Path.home()/'.radio-chaos'/'stems-v45_9'))).expanduser().resolve()
MAX_BYTES=150*1024*1024
EXTS={'.wav','.mp3','.flac','.m4a','.aac','.aif','.aiff','.ogg','.opus'}
MODELS={'htdemucs':('vocals','drums','bass','other'),'htdemucs_6s':('vocals','drums','bass','guitar','piano','other'),'uvr-mdx-inst-hq3':('vocals','instrumental')}
UVR_CHECKPOINT='UVR-MDX-NET-Inst_HQ_3.onnx'
TOKEN=os.environ.get('RADIO_CHAOS_STEM_TOKEN') or secrets.token_urlsafe(28)
JOBS={}
LOCK=threading.RLock()

def available():
    return (importlib.util.find_spec('demucs') is not None or importlib.util.find_spec('audio_separator') is not None) and shutil.which('ffmpeg') is not None

def cached_model_weights():
    # Official Demucs 4 checkpoint names, downloaded by PyTorch Hub on first inference.
    torch_root=Path(os.getenv('TORCH_HOME', str(Path(os.getenv('XDG_CACHE_HOME',str(Path.home()/'.cache')))/'torch')))
    checkpoints=torch_root/'hub'/'checkpoints'
    return {'htdemucs':(checkpoints/'955717e8-8726e21a.th').is_file(),
            'htdemucs_6s':(checkpoints/'5c90dfd2-34c22ccb.th').is_file()}

def public(job):
    return {k:job[k] for k in ('id','state','model','name','created','stems','error','audio_info') if k in job}

def engine_available(model):
    package='audio_separator' if model=='uvr-mdx-inst-hq3' else 'demucs'
    return importlib.util.find_spec(package) is not None and shutil.which('ffmpeg') is not None

def separate_uvr(inp:Path,out:Path):
    """Run real pretrained UVR MDX separation, never a synthetic fallback."""
    if not engine_available('uvr-mdx-inst-hq3'):
        raise RuntimeError('Install audio-separator[cpu] and ffmpeg to use UVR MDX.')
    from audio_separator.separator import Separator
    separator=Separator(output_dir=str(out),output_format='WAV')
    separator.load_model(model_filename=UVR_CHECKPOINT)
    produced=separator.separate(str(inp))
    result={}
    for filename in produced:
        path=Path(filename)
        if not path.is_absolute():path=out/path
        if not path.is_file() or path.stat().st_size<=44:continue
        name=path.stem.lower()
        if 'instrumental' in name or 'no vocals' in name:result['instrumental']=path
        elif 'vocals' in name or 'vocal' in name:result['vocals']=path
    if set(result)!={'vocals','instrumental'}:
        raise RuntimeError('UVR model did not produce both vocal and instrumental WAV stems: '+str(produced))
    return result

def actually_separate(inp:Path,out:Path,model:str):
    """Actual pretrained separation, not a fake stereo L/R decomposition."""
    if model=='uvr-mdx-inst-hq3':return separate_uvr(inp,out)
    if not engine_available(model):
        raise RuntimeError('Install Demucs and ffmpeg on the host computer to separate instruments.')
    # The Demucs PyTorch package uses -n / -o. The prior bridge passed incompatible CLI args.
    args=[sys.executable,'-m','demucs','-n',model,'-o',str(out),'-d','cpu',str(inp)]
    completed=subprocess.run(args,capture_output=True,text=True,timeout=3600,check=False)
    if completed.returncode:
        details=(completed.stderr or completed.stdout or 'unknown model error')[-1700:]
        raise RuntimeError('Real Demucs inference failed: '+details)
    files={}
    for path in out.rglob('*.wav'):
        key=path.stem.lower()
        if key in MODELS[model] and path.stat().st_size>44:
            files[key]=path
    if set(files)!=set(MODELS[model]):
        raise RuntimeError('Incomplete AI output: expected '+','.join(MODELS[model])+', got '+','.join(files)+'.')
    return files

def probe_audio(path:Path):
    """Validate a real, decodable audio stream before launching an expensive model."""
    ffprobe=shutil.which('ffprobe')
    if not ffprobe:raise RuntimeError('ffprobe (part of FFmpeg) is required to validate audio uploads.')
    result=subprocess.run([ffprobe,'-v','error','-select_streams','a:0','-show_entries','stream=codec_name,sample_rate,channels:format=duration','-of','json',str(path)],capture_output=True,text=True,timeout=30)
    if result.returncode:raise RuntimeError('Audio decoding probe failed: '+result.stderr[-300:])
    try:
        data=json.loads(result.stdout);stream=data['streams'][0];duration=float(data['format']['duration'])
        if not stream.get('codec_name') or int(stream.get('channels',0))<1 or duration<=0:raise ValueError()
        return {'codec':stream['codec_name'],'channels':int(stream['channels']),'duration_seconds':round(duration,3),'sample_rate':int(stream.get('sample_rate') or 0)}
    except (ValueError,KeyError,IndexError,TypeError):raise RuntimeError('No valid audio stream or duration found in uploaded file.')

def worker(jid):
    with LOCK:
        job=JOBS[jid];job['state']='running'
    try:
        result=actually_separate(Path(job['input']),Path(job['output']),job['model'])
        with LOCK:
            job['files']={name:str(path) for name,path in result.items()}
            job['stems']=[name for name in MODELS[job['model']] if name in result]
            job['state']='done'
    except Exception as exc:
        with LOCK:
            job['state']='error';job['error']=str(exc)[-2000:]

class Handler(BaseHTTPRequestHandler):
    server_version='RadioChaosStemEditor/45.34'
    def log_message(self,fmt,*args):
        print('STEMS',self.address_string(),fmt%args,flush=True)
    def cors(self):
        origin=self.headers.get('Origin','')
        if origin and origin not in ('null',f'http://{self.headers.get("Host","")}',f'https://{self.headers.get("Host","")}'):
            # Do not grant cross-origin access to other websites.
            return
        if origin:self.send_header('Access-Control-Allow-Origin',origin)
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type,X-Radio-Chaos-Token,X-RC-Model,X-RC-Filename')
        self.send_header('Vary','Origin')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
    def response(self,status,body:bytes,mime:str='application/json; charset=utf-8',filename=''):
        self.send_response(status);self.cors();self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)))
        if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers()
        try:self.wfile.write(body)
        except (BrokenPipeError,ConnectionResetError):pass
    def stream_file(self,path:Path,mime:str,filename:str):
        if not path.is_file():return self.json(404,{'error':'Output file is missing.'})
        self.send_response(200);self.cors();self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(path.stat().st_size))
        self.send_header('Content-Disposition',f'attachment; filename="{filename}"');self.end_headers()
        try:
            with path.open('rb') as f:
                while True:
                    block=f.read(1024*1024)
                    if not block:break
                    self.wfile.write(block)
        except (BrokenPipeError,ConnectionResetError):pass
    def json(self,status,content):self.response(status,json.dumps(content,default=str).encode())
    def origin_allowed(self):
        origin=self.headers.get('Origin','')
        if not origin:return True
        return origin in (f'http://{self.headers.get("Host","")}',f'https://{self.headers.get("Host","")}')
    def authorized(self):
        if not self.origin_allowed():
            self.json(403,{'error':'Cross-origin stem API requests are not allowed.'});return False
        if not secrets.compare_digest(self.headers.get('X-Radio-Chaos-Token',''),TOKEN):
            self.json(401,{'error':'Wrong or missing stem-service token (copy it from the Python server terminal).'});return False
        return True
    def do_OPTIONS(self):self.send_response(204);self.cors();self.end_headers()
    def do_GET(self):
        route=urlsplit(self.path).path
        if route in ('/','/app','/Radio_Chaos_v45_35_Installable_App_Mode.html'):
            if not APP.exists():return self.json(404,{'error':'App HTML file is missing from the server folder.'})
            return self.response(200,APP.read_bytes(),'text/html; charset=utf-8')
        if route in ('/manifest.webmanifest','/service-worker.js','/icons/icon-180.png','/icons/icon-192.png','/icons/icon-512.png'):
            static=HERE/route.lstrip('/')
            if not static.is_file():return self.json(404,{'error':'Static app asset missing'})
            mime='application/manifest+json' if route.endswith('.webmanifest') else 'application/javascript; charset=utf-8' if route.endswith('.js') else 'image/png'
            return self.response(200,static.read_bytes(),mime)
        if route=='/rc-stems/health':
            return self.json(200,{'service':'radio-chaos-stems','version':'45.35.0','available':available(),'engines':{'demucs':engine_available('htdemucs'),'uvr_mdx':engine_available('uvr-mdx-inst-hq3')},'models':list(MODELS),'ffmpeg':bool(shutil.which('ffmpeg')),'model_ready':{m:(engine_available(m) and cached_model_weights().get(m,False)) if m!='uvr-mdx-inst-hq3' else False for m in MODELS},'cached_models':cached_model_weights(),'note':'Engine installed does not mean model weights are cached. Demucs may download weights on first inference. UVR model readiness is unverified until inference succeeds. No synthetic separation.'})
        if not self.authorized():return
        m=re.fullmatch(r'/rc-stems/jobs/([a-f0-9]{32})(?:/(?:stems/([a-z]+)|archive))?',route)
        if not m:return self.json(404,{'error':'Unknown endpoint'})
        jid,stem=m.group(1),m.group(2)
        with LOCK:
            job=JOBS.get(jid)
            if not job:return self.json(404,{'error':'No such stem job'})
            snap=public(job);files=job.get('files',{}).copy()
        if route==f'/rc-stems/jobs/{jid}':return self.json(200,snap)
        if snap['state']!='done':return self.json(409,{'error':'The model has not finished separation.'})
        if stem:
            if stem not in files:return self.json(404,{'error':'Stem was not produced by model'})
            path=Path(files[stem]);return self.stream_file(path,'audio/wav',stem+'.wav')
        if route.endswith('/archive'):
            out=Path(job['output'])/'real_stems.zip'
            if not out.exists():
                with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as z:
                    for key,path in files.items():z.write(path,arcname=key+'.wav')
            return self.stream_file(out,'application/zip','real_stems.zip')
        self.json(404,{'error':'Unknown endpoint'})
    def do_POST(self):
        if urlsplit(self.path).path!='/rc-stems/jobs':return self.json(404,{'error':'Unknown endpoint'})
        if not self.authorized():return
        if not available():return self.json(503,{'error':'Install Demucs or audio-separator and ffmpeg on the host before separating.'})
        try:size=int(self.headers.get('Content-Length','0'))
        except ValueError:size=0
        if size<44 or size>MAX_BYTES:return self.json(413,{'error':'A real audio recording between 44 bytes and 150 MB is required.'})
        model=self.headers.get('X-RC-Model','htdemucs_6s')
        if model not in MODELS:return self.json(400,{'error':'Unsupported separation model.'})
        if not engine_available(model):return self.json(503,{'error':'Selected separation engine is not installed or ffmpeg is missing.'})
        name=Path(unquote(self.headers.get('X-RC-Filename','song.wav'))).name
        name=re.sub(r'[^A-Za-z0-9_.-]','_',name)[:100]
        if Path(name).suffix.lower() not in EXTS:return self.json(400,{'error':'Unsupported recording format.'})
        with LOCK:
            if any(j['state'] in ('running','queued') for j in JOBS.values()):return self.json(429,{'error':'One source separation already running. Finish that job before another.'})
        jid=uuid.uuid4().hex;jobroot=ROOT/jid;jobroot.mkdir(parents=True);inp=jobroot/name;out=jobroot/'separated';out.mkdir()
        try:
            with inp.open('wb') as f:
                while size>0:
                    chunk=self.rfile.read(min(size,1048576))
                    if not chunk:raise EOFError('Recording upload interrupted')
                    f.write(chunk);size-=len(chunk)
        except (OSError,EOFError) as e:
            shutil.rmtree(jobroot,ignore_errors=True);return self.json(400,{'error':str(e)})
        try:audio_info=probe_audio(inp)
        except (RuntimeError,subprocess.TimeoutExpired) as e:
            shutil.rmtree(jobroot,ignore_errors=True)
            return self.json(422,{'error':'Invalid or unreadable recording: '+str(e)})
        job={'id':jid,'state':'queued','model':model,'name':name,'created':datetime.now(timezone.utc).isoformat(),'stems':[],'error':'','input':str(inp),'output':str(out),'files':{},'audio_info':audio_info}
        with LOCK:JOBS[jid]=job
        threading.Thread(target=worker,args=(jid,),daemon=True).start()
        self.json(202,public(job))

def main():
    p=argparse.ArgumentParser(description='Radio Chaos full-track Demucs splitter and editor')
    p.add_argument('--host',default='127.0.0.1',help='Use 0.0.0.0 only on a trusted, private home network for iPhone')
    p.add_argument('--port',type=int,default=8765)
    a=p.parse_args()
    ROOT.mkdir(parents=True,exist_ok=True)
    print('Radio Chaos 45.35 dual-engine stem server',flush=True)
    print('Stem API token:',TOKEN,flush=True)
    print('Demucs available:',engine_available('htdemucs'),'UVR MDX available:',engine_available('uvr-mdx-inst-hq3'),flush=True)
    print(f'Open http://localhost:{a.port}/ on this computer',flush=True)
    if a.host=='0.0.0.0':print('For iPhone: http://YOUR_COMPUTER_LAN_IP:'+str(a.port)+'/  (same private Wi-Fi only; HTTP is unencrypted)',flush=True)
    print('Keep the token private; never expose this HTTP service to the public internet.',flush=True)
    ThreadingHTTPServer((a.host,a.port),Handler).serve_forever()

if __name__=='__main__':main()
